package de.krypto.arbitrage;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.setBackgroundColor(0xFF0B1220);
        web.addJavascriptInterface(new MarketBridge(), "AndroidMarket");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    public class MarketBridge {
        @JavascriptInterface public void refreshPrices() {
            final String[] coins = {"BTC", "ETH", "SOL"};
            final String[] krakenPairs = {"XBTEUR", "ETHEUR", "SOLEUR"};
            final String[] bitstampPairs = {"btceur", "etheur", "soleur"};
            final JSONObject data = new JSONObject();
            try {
                data.put("updated", System.currentTimeMillis());
                for (String coin : coins) {
                    JSONObject entry = new JSONObject();
                    entry.put("sources", new JSONArray());
                    data.put(coin, entry);
                }
            } catch (JSONException ignored) {}
            ExecutorService pool = Executors.newFixedThreadPool(12);
            CountDownLatch latch = new CountDownLatch(12);
            for (int i = 0; i < coins.length; i++) {
                final String coin = coins[i];
                final String krakenPair = krakenPairs[i];
                final String bitstampPair = bitstampPairs[i];
                final String product = coin + "-EUR";
                pool.execute(() -> { try { addTicker(data, coin, fetchKraken(krakenPair)); } catch (Exception ignored) {} finally { latch.countDown(); }});
                pool.execute(() -> { try { addTicker(data, coin, fetchCoinbase(product)); } catch (Exception ignored) {} finally { latch.countDown(); }});
                pool.execute(() -> { try { addTicker(data, coin, fetchBitstamp(bitstampPair)); } catch (Exception ignored) {} finally { latch.countDown(); }});
                pool.execute(() -> { try { addTicker(data, coin, fetchBitvavo(product)); } catch (Exception ignored) {} finally { latch.countDown(); }});
            }
            new Thread(() -> {
                try { latch.await(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                pool.shutdown();
                try { data.put("updated", System.currentTimeMillis()); } catch (JSONException ignored) {}
                final String payload = data.toString();
                runOnUiThread(() -> web.evaluateJavascript("window.receiveLivePrices(JSON.parse(" + JSONObject.quote(payload) + "))", null));
            }).start();
        }

        private void addTicker(JSONObject data, String coin, JSONObject ticker) throws JSONException {
            synchronized (data) {
                data.getJSONObject(coin).getJSONArray("sources").put(ticker);
            }
        }

        private JSONObject fetchKraken(String pair) throws Exception {
            JSONObject root = getJson("https://api.kraken.com/0/public/Ticker?pair=" + pair);
            JSONObject result = root.getJSONObject("result");
            String key = result.keys().next();
            JSONObject t = result.getJSONObject(key);
            return makeTicker("Kraken", Double.parseDouble(t.getJSONArray("b").getString(0)),
                    Double.parseDouble(t.getJSONArray("a").getString(0)),
                    Double.parseDouble(t.getJSONArray("c").getString(0)));
        }

        private JSONObject fetchCoinbase(String product) throws Exception {
            JSONObject t = getJson("https://api.exchange.coinbase.com/products/" + product + "/ticker");
            return makeTicker("Coinbase", t.getDouble("bid"), t.getDouble("ask"), t.getDouble("price"));
        }

        private JSONObject fetchBitstamp(String pair) throws Exception {
            JSONObject t = getJson("https://www.bitstamp.net/api/v2/ticker/" + pair + "/");
            return makeTicker("Bitstamp", t.getDouble("bid"), t.getDouble("ask"), t.getDouble("last"));
        }

        private JSONObject fetchBitvavo(String market) throws Exception {
            JSONObject root = getJson("https://api.bitvavo.com/v2/ticker/book?market=" + market);
            if (root.has("_array")) root = root.getJSONArray("_array").getJSONObject(0);
            return makeTicker("Bitvavo", root.getDouble("bid"), root.getDouble("ask"),
                    (root.has("last") ? root.getDouble("last") : (root.getDouble("bid") + root.getDouble("ask")) / 2.0));
        }

        private JSONObject makeTicker(String exchange, double bid, double ask, double last) throws JSONException {
            JSONObject out = new JSONObject();
            out.put("exchange", exchange);
            out.put("bid", bid);
            out.put("ask", ask);
            out.put("last", last);
            return out;
        }

        private JSONObject getJson(String urlString) throws Exception {
            HttpURLConnection connection = (HttpURLConnection) new URL(urlString).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(7000);
            connection.setReadTimeout(7000);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "KryptoArbitrageAndroid/1.2");
            try {
                int code = connection.getResponseCode();
                InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
                if (stream == null) throw new Exception("HTTP " + code);
                BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
                StringBuilder body = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) body.append(line);
                reader.close();
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + body);
                String text = body.toString().trim();
                if (text.startsWith("[")) {
                    JSONArray arr = new JSONArray(text);
                    JSONObject wrapper = new JSONObject();
                    wrapper.put("_array", arr);
                    return wrapper;
                }
                return new JSONObject(text);
            } finally { connection.disconnect(); }
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
